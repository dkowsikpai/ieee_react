import React from 'react';
import './static/main.css';

import standoutImg from './static/images/stand_out.svg';
import ieeeImg from './static/images/ieee.png';


import bioImg from './static/images/bio.svg';


class App extends React.Component{
    render() {
        return (
            <div className="row">
                <Header/>
                <About/>
            </div>
        );
    }


}

class Header extends React.Component{
    render() {
        return(
            <div className="container-fluid">
                <div className="row m-3">
                    <div className="col-lg-3 custMenu"  data-tag='home' >Home</div>
                    <div className="col-lg-3 custMenu"  data-tag='gallery' >Gallery</div>
                    <div className="col-lg-3 custMenu"  data-tag='execom'>Execom</div>
                    <div className="col-lg-3 custMenu"  data-tag='act'>Activities</div>
                </div>
                <div className="row">
                    <img src={ieeeImg} alt="ieee" style={{margin: "3vh"}} />
                    <img src={standoutImg} width="100%" height="100%" align="right" className="mt-3 logoIllustration" style={{ position: "absolute", marginLeft: "10vw"}}/>
                </div>
                <div className="row">
                    <div className="text-anim m-5">
                        <h1 style={{fontFamily: `'Montserrat', sans-serif`}}>GEC, Thrissur</h1>
                    </div>
                </div>
            </div>
        );
    }
}

class About extends React.Component{
    render() {
        return(
            <div className="container-fluid" style={{marginTop: "40vh"}}>
                    <img src={bioImg} alt="Bio" className="aboutIllustration"/>
                    <h4 className="aboutText">
                        Government Engneering College, Thrissur <br/> is one of the most prestigious institutions in Kerala.
                    </h4>
            </div>
        );
    }
}


export default App;

